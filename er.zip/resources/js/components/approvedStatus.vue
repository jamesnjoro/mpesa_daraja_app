<template>
    <div class="card text-center">
        <div class="card-header">
            Message
        </div>
        <div class="card-body">
            <h5 class="card-title">Account not approved</h5>
            <p class="card-text">Please contact the admin to approve your account.</p>
        </div>
    </div>
</template>

<script>
export default {
    name: "approvedStatus",
    props:[]
}
</script>



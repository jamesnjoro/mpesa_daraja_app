@extends('layouts.app')

@section('content')
    <transactions></transactions>
@endsection

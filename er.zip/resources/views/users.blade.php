@extends('layouts.app')
@section('content')
    <users url="{{ route('users') }}"></users>
    <script type="application/javascript">

    </script>
@endsection

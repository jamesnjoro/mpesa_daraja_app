<?php $__env->startSection('content'); ?>
    <users url="<?php echo e(route('users')); ?>"></users>
    <script type="application/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/projects/mpesa_daraja_app/resources/views/users.blade.php ENDPATH**/ ?>
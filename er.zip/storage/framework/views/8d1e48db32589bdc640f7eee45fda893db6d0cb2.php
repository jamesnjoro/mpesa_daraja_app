<?php $__env->startSection('content'); ?>
    <approve-status v-if="<?php echo e($user->role); ?> == 0 && <?php echo e($user->approved); ?> == 0"></approve-status>
    <transactions v-if="<?php echo e($user->role); ?> == 0 && <?php echo e($user->approved); ?> == 1"></transactions>
    <div v-if="<?php echo e($user->role); ?> == 1" class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Status</div>

                    <div class="card-body">
                        <status ck="<?php echo e($setting->ck); ?>"></status>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-2">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Register API Urls</div>

                    <div class="card-body">
                        <api-form
                            ck="<?php echo e($setting->ck); ?>"
                            cs="<?php echo e($setting->cs); ?>"
                            sc="<?php echo e($setting->shortcode); ?>"
                            vurl="<?php echo e($setting->vURL); ?>"
                            aurl="<?php echo e($setting->aURL); ?>"
                        ></api-form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/projects/mpesa_daraja_app/resources/views/home.blade.php ENDPATH**/ ?>